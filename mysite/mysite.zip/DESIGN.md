---
name: Александр Блинов — Portfolio
description: Soft Liquid Bento portfolio — bold, modern, confident frontend craft
colors:
  background: "#F8F6F2"
  foreground: "#27262B"
  card: "#FDFCFA"
  muted: "#EDEAE4"
  muted-foreground: "#68666E"
  primary: "#7B4FCC"
  primary-foreground: "#FFFFFF"
  secondary: "#C44D7A"
  secondary-foreground: "#FFFFFF"
  accent: "#429B7A"
  accent-foreground: "#FFFFFF"
  border: "#E3DFD8"
typography:
  display:
    fontFamily: "var(--font-geist-sans), system-ui, sans-serif"
    fontSize: "clamp(1.875rem, 5vw, 2.75rem)"
    fontWeight: 700
    lineHeight: 1.15
    letterSpacing: "-0.02em"
  body:
    fontFamily: "var(--font-geist-sans), system-ui, sans-serif"
    fontSize: "1rem"
    fontWeight: 400
    lineHeight: 1.6
    letterSpacing: "normal"
  label:
    fontFamily: "var(--font-geist-sans), system-ui, sans-serif"
    fontSize: "0.8125rem"
    fontWeight: 500
    lineHeight: 1.2
    letterSpacing: "normal"
rounded:
  sm: "0.625rem"
  md: "1rem"
  lg: "1.375rem"
  xl: "2rem"
  pill: "9999px"
spacing:
  section-y: "4rem"
  card-pad: "1.25rem"
  nav-pill-x: "0.9375rem"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.primary-foreground}"
    rounded: "{rounded.pill}"
    padding: "12px 20px"
  button-secondary:
    backgroundColor: "glass-surface"
    textColor: "{colors.foreground}"
    rounded: "{rounded.pill}"
    padding: "12px 20px"
  card-glass:
    backgroundColor: "{colors.card}"
    textColor: "{colors.foreground}"
    rounded: "{rounded.lg}"
    padding: "{spacing.card-pad}"
---

## Overview

**Creative North Star: Liquid Confidence**

Визуальная система портфолио — **Soft Liquid Bento / Liquid Glass**: мягкие стеклянные поверхности, bento-сетки, violet → rose градиенты с emerald-акцентом для статусов. Настроение: **смелый, современный, уверенный** frontend-craft без корпоративной скуки и без AI-шаблонности.

- **Mood:** premium-but-approachable, tech-forward, чистый ритм секций.
- **Layout:** одностраничный scroll, sticky glass header, card/bento blocks, max-width container (`max-w-6xl`).
- **Motion:** лёгкие CSS transitions (180–280ms), hover lift, drawer slide; `prefers-reduced-motion` обязателен.
- **Anti-feel:** серая CV-простыня, перегруженный glass, кислотные неоны, одинаковые card-grid без иерархии.

Canonical tokens live in `styles/tokens.css`, `styles/theme.css`, bridged via `app/globals.css` (`@theme inline`). Components use semantic Tailwind tokens (`bg-primary`, `text-muted-foreground`) — не хардкодить hex в JSX.

## Colors

### Primary — Electric Violet
`hsl(265 62% 55%)` — основной brand, CTA, nav hover, gradient start. Уверенный, не пастельный.

### Secondary — Rose Signal
`hsl(340 52% 56%)` — второй градиентный stop, акцентные badges, warmth без «кремового AI-default».

### Accent — Emerald Status
`hsl(158 42% 45%)` — availability, success hints, status dots. Не заменяет primary.

### Neutrals — Warm Paper / Graphite
- **Background** `hsl(35 28% 97%)` — тёплый off-white, не beige-slop.
- **Foreground** `hsl(240 6% 16%)` — graphite ink, читаемый body text.
- **Muted** surfaces для chips и secondary text — контраст ≥4.5:1 на body.

### Gradients
- `--gradient-primary`: violet → rose (135deg) — buttons, logo mark, featured badges.
- `--gradient-ambient`: radial violet/rose/emerald washes on `body` background.
- `--gradient-profile`: hero profile card wash.

### Glass layer
- `--glass-bg`, `--glass-header-bg`, `--glass-border`, `--glass-blur`, `--glass-highlight`
- Utilities: `.glass-surface`, `.glass-header`, `.btn-glass`

### Dark theme
`[data-theme='dark']` in `styles/theme.css` — deeper surfaces, brighter primary, reduced ambient glow. Toggle via `ThemeToggle` + `portfolio-theme` localStorage.

## Typography

- **Font stack:** Geist Sans (latin + cyrillic), Geist Mono for code accents.
- **H1 (hero tagline):** bold, `tracking-tight`, max ~2.75rem desktop; `text-wrap: balance` recommended.
- **Section titles:** via `Section` component — clear hierarchy above body.
- **Body:** `text-base` / `text-lg` for pitch; `text-muted-foreground` for secondary — **verify contrast** on tinted backgrounds.
- **Labels/chips:** `text-xs` / `text-sm`, medium weight, pill containers.
- **Don't:** gradient text on body copy; display size >6rem; letter-spacing tighter than -0.04em on display.

## Elevation

- **Philosophy:** layered glass + soft shadow, not flat Material cards everywhere.
- `--shadow-card`: dual soft shadows (violet-tinted ambient).
- `.card-hover`: translateY(-2px) + stronger shadow on hover.
- Glass: `inset 0 1px 0` highlight + outer blur shadow.
- Header: denser `--glass-header-bg` for nav readability over content.
- No arbitrary z-index (9999); header `z-50`, drawer `z-[100+]`.

## Components

### Button
- **Primary:** `.btn-gradient` — violet→rose, white text, soft glow shadow.
- **Secondary:** `.btn-glass` — glass surface, border, hover primary tint.
- **Ghost:** text-only for footer links.

### Card
- Variants: `default` / `glass` / `muted` / `solid`; optional `hover` prop.
- Bento grids: featured cell wider (stats, services, skills, projects).

### Badge
- Variants: `default`, `glass`, `accent`, `gradient` — hero floating chips, skill tags.

### Navigation
- **Logo:** inline SVG gradient mark + name; link `#hero`.
- **Desktop nav:** `.nav-link` pills — glass fill, hover glow, `translateY(-1px)`.
- **Mobile:** right drawer, large `.nav-link--drawer`, overlay + scroll lock.

### Theme toggle
- Liquid glass pill switch; knob gradient; icons sun/moon; `role="switch"`.

### Modal
- Portal dialog for privacy policy; focus trap pattern.

### Section shell
- `Container` max-w-6xl; `Section` with `id`, `title`, `description`, `scroll-mt-24`.

## Do's and Don'ts

**Do**
- Use semantic tokens and existing utilities (`.glass-surface`, `.btn-gradient`, `.nav-link`).
- Keep bento rhythm: one featured cell per grid where it helps scan.
- Russian UI copy; frontend-first positioning.
- Test light + dark + mobile drawer.
- Respect `prefers-reduced-motion`.

**Don't**
- Hardcode brand hex in components — extend `styles/tokens.css` first.
- Add nested cards inside cards.
- Introduce UI libraries or animation libraries without explicit approval.
- Default to CRM-only copy or generic AI portfolio tropes.
- Use English status labels (`Available`, `Mini dashboard`) in user-facing UI.
- Side-stripe accent borders (>1px colored left/right borders on cards).
