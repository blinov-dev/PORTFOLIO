# AGENTS.md

Project instructions for AI coding agents.

Before significant changes:
1. Read `.cursor/docs/project-profile.md`.
2. Read `.cursor/docs/current-task.md`.
3. Read `.cursor/docs/codebase-map.md`.
4. If UI is involved, read `.cursor/docs/component-inventory.md` and `.cursor/docs/theme-guide.md`.

Core rules:
- Do not create duplicate architecture, components, API clients, stores, or style tokens.
- Follow the selected project profile.
- Use Tailwind-first styling, CSS variables for tokens/themes, and SCSS Modules only for complex scoped styles.
- Custom UI components are default; document reusable components in `.cursor/docs/component-inventory.md`.
- Do not commit, push, reset, clean, rebase, merge, or edit secrets without explicit user confirmation.
- Run the smallest relevant quality checks after code changes.

## Design Context (Impeccable)

Strategic and visual context for UI work:

- **PRODUCT.md** — register (`brand`), users, purpose, personality, anti-references, principles.
- **DESIGN.md** — Soft Liquid Bento / Liquid Glass tokens, typography, components, do's/don'ts.

Read both before design, critique, polish, or visual iteration commands (`$impeccable *`).
