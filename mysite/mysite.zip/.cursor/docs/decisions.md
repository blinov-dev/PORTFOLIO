# Decisions Log

Кратко фиксируй только решения, которые влияют на будущие задачи Cursor.
Не превращать в дневник разработки.

## Format

```md
## YYYY-MM-DD — Decision title

Decision: ...
Reason: ...
Impacts: ...
```

## Decisions

TODO
