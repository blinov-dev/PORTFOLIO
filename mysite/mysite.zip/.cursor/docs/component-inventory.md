# Component Inventory

Инвентарь UI-компонентов портфолио Александра Блинова. Cursor не должен плодить дубли — перед созданием проверять этот файл и существующий код.

## Правило обновления

Cursor обязан обновлять этот файл, если в задаче:
- создан новый reusable UI-компонент;
- существенно изменён API существующего UI-компонента;
- создан wrapper над компонентом UI-библиотеки;
- выбран или подключён UI-kit.

Одноразовые блоки, живущие только внутри одной feature/page, сюда не обязательны.

## UI mode

- **Default:** custom UI components.
- **Selected UI library:** none.
- **Wrapper policy:** не применимо до выбора библиотеки.

## Base UI

| Component | Path | Status | Notes |
|---|---|---|---|
| Button | `components/ui/button.tsx` | **exists** | `variant`: primary (violet→rose gradient), secondary (glass), ghost |
| SectionHeading | `components/ui/section-heading.tsx` | **exists** | Section h2 with violet→rose gradient accent behind text |
| Badge | `components/ui/badge.tsx` | **exists** | `variant`: default, glass, accent (emerald), gradient |
| Card | `components/ui/card.tsx` | **exists** | `variant`: default/glass, muted, solid; `hover?: boolean` |
| IconButton | `components/ui/icon-button.tsx` | **exists** | Glass surface; violet hover |
| SkillTiltTile | `components/ui/skill-tilt-tile.tsx` | **exists** | **Client**; glass skill tile; `--skill-brand` hover color; cursor-follow tilt (desktop); idle float on hero skills |
| Modal | `components/ui/modal.tsx` | **exists** | **Client**; portal dialog |
| ThemeToggle | `components/ui/theme-toggle.tsx` | **exists** | **Client**; light/dark pill switch, localStorage |
| Link | `components/ui/link` | missing | Пока используются нативные `<a>` и `Button href` |
| Tooltip | — | not planned (MVP) | — |
| Spinner | — | not planned (MVP) | — |
| Avatar | — | not planned | ProfileImage в features/hero |
| Separator | — | not planned (MVP) | — |

## Layout

| Component | Path | Status | Notes |
|---|---|---|---|
| Container | `components/layout/container.tsx` | **exists** | Props: `children`, `className`; max-w-6xl wrapper |
| Section | `components/layout/section.tsx` | **exists** | Props: `id?`, `title?`, `description?`, `children`, `className`; scroll-mt-24; uses SectionHeading |
| Header | `components/layout/header.tsx` | **exists** | Sticky glass header + Logo + nav pills + theme toggle + mobile menu |
| Footer | `components/layout/footer.tsx` | **exists** | Copyright + link to #contacts |
| Logo | `components/layout/logo.tsx` | **exists** | AB mark (inline SVG gradient) + name; link `#hero` |
| SiteNav | `components/layout/site-nav.tsx` | **exists** | Pill nav links; `size`: default/large (drawer) |
| MobileMenu | `components/layout/mobile-menu.tsx` | **exists** | **Client Component**; right drawer via portal, overlay, scroll lock, Escape close |
| PageShell | — | not used | Composition in `app/page.tsx` (Header + main + Footer) |
| Grid | — | not used | Tailwind grid utilities |

## Portfolio sections (feature-level)

| Component | Path | Status | Notes |
|---|---|---|---|
| HeroSection | `features/hero/hero-section.tsx` | **exists** | Server; hero grid, CTA, socials |
| ProfileImage | `features/hero/profile-image.tsx` | **exists** | Server; placeholder via next/image |
| AboutSection | `features/about/about-section.tsx` | **exists** | Server; #about; glass panel with lead, paragraphs, chips |
| StatsSection | `features/stats/stats-section.tsx` | **exists** | Server; Card × 4 inline (no StatCard file) |
| ServicesSection | `features/services/services-section.tsx` | **exists** | Server; #services; task tabs (desktop) + accordion (mobile) |
| ServicesInteractive | `features/services/services-interactive.tsx` | **exists** | **Client**; tablist/tabpanel + accordion for frontend tasks |
| SkillsSection | `features/skills/skills-section.tsx` | **exists** | Server; #skills; interactive liquid skill constellation |
| SkillIcon | `features/skills/skill-icon.tsx` | **exists** | **Client**; react-icons mapping for skill tiles |
| ProjectsSection | `features/projects/projects-section.tsx` | **exists** | Server; #projects |
| ProjectCard | `features/projects/project-card.tsx` | **exists** | mockup preview, outcome line, no fake links |
| ProjectMockup | `features/projects/project-mockup.tsx` | **exists** | CSS mockups: crm, b2b, admin |
| WorkProcessSection | `features/work-process/work-process-section.tsx` | **exists** | Server; #process; glass pipeline timeline with connectors |
| ContactsSection | `features/contacts/contacts-section.tsx` | **exists** | Server; #contacts; unified vertical glass panel |
| ContactForm | `features/contacts/contact-form.tsx` | **exists** | **Client**; POST /api/contact, validation, aria-disabled submit |
| ContactIconGlyph | `features/contacts/contact-icon.tsx` | **exists** | Shared contact icons for cards and social links |
| PrivacyModal | `features/contacts/privacy-modal.tsx` | **exists** | **Client**; policy text in modal |
| PrivacyPolicyLink | `features/contacts/privacy-policy-link.tsx` | **exists** | **Client**; opens PrivacyModal (footer) |
| SocialLinks | `features/contacts/social-links.tsx` | **exists** | Server; IconButton row |

## Theme

| Component | Path | Status | Notes |
|---|---|---|---|
| ThemeInitScript | `components/theme/theme-init-script.tsx` | **exists** | Inline script; restores theme before hydration |
| useTheme | `hooks/use-theme.ts` | **exists** | Client hook; `useSyncExternalStore` |
| ThemeToggle | `components/ui/theme-toggle.tsx` | **exists** | Header (desktop) + mobile drawer |

## Forms

| Component | Path | Status | Notes |
|---|---|---|---|
| ContactForm | `features/contacts/contact-form.tsx` | **exists** | Native inputs in component; no separate Input primitive |

## Naming conventions

- Base primitives: `components/ui/<name>.tsx`
- Layout: `components/layout/<name>.tsx`
- Feature sections: `features/<feature>/<name>.tsx`
- Co-locate types in `lib/content/` or inline

## Rules for new components

Before creating a new reusable component:
1. Search this file.
2. Search `components/`, `features/*/`.
3. Prefer extending existing component props over creating a duplicate.
4. If new component is justified, add it here with path, props summary, and usage notes.
5. Use semantic theme tokens — no hardcoded hex in components.
