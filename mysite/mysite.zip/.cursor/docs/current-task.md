# Current Task

Этот файл хранит активный scope, чтобы Cursor не прыгал между задачами.

## Active task

TODO: кратко описать текущую задачу.

## Goal

TODO: какой минимальный результат нужен.

## Scope

Included:
- TODO

Not included:
- TODO

## Files likely involved

- TODO

## Risks / constraints

- Do not change architecture without confirmation.
- Do not add new dependencies without confirmation.
- Do not touch `.env` secrets.
- Do not commit/push.

## Done criteria

- TODO
- Quality checks completed or explicitly skipped with reason.
