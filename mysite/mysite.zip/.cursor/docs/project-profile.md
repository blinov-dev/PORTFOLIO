# Project Profile

Профиль проекта для персонального сайта-портфолио. Cursor обязан читать этот файл перед крупными задачами и не навязывать архитектуру, если профиль уже выбран.

## About

| Field | Value |
|---|---|
| **Owner** | Александр Блинов |
| **Role** | Frontend-разработчик, 3+ года опыта |
| **Site type** | Персональный сайт-визитка / портфолио |
| **Primary goal** | Фриланс, отклики на вакансии, отправка работодателям и заказчикам |
| **Language (UI)** | Русский (основной); английская версия — по необходимости позже |
| **Photo** | Placeholder на первом этапе; позже — личная фотография в стилизованном формате |
| **Design reference** | `public/references/portfolio-reference.jpg` — вдохновение по композиции и настроению, не копировать 1:1 |

## Project type

**Current:** `frontend-only-landing`

Одностраничный (или мало-страничный) маркетинговый сайт без backend, БД и API на первом этапе.

## Stack

| Area | Choice |
|---|---|
| Language | TypeScript |
| Frontend | Next.js 16 App Router + React 19 |
| Backend | none (первый этап) |
| DB | none |
| State | local state / React hooks (без глобального state manager) |
| Forms | native / custom (контактная форма — позже, без backend на старте) |
| Styling | Tailwind CSS v4 + CSS variables + optional SCSS Modules |
| UI | custom UI components by default |
| UI library | none |
| Theme | light/dark + optional brand tokens |
| Package manager | npm |
| Tests | none (пока не настроены) |
| Deploy | Vercel (рекомендуется для Next.js) / static export при необходимости |

## Content sections (planned)

Ориентир по структуре страницы (по референсу и целям сайта):

1. **Hero** — фото, имя, роль, краткий pitch, навигация, CTA, соцсети.
2. **Stats / facts** — опыт, проекты, ключевые метрики.
3. **Skills / stack** — технологии, инструменты.
4. **Cases / projects** — портфолио работ.
5. **Services / value** — чем могу помочь заказчику.
6. **Contacts** — способы связи (email, Telegram, GitHub и т.д.).

Точный набор секций и порядок — уточнять при реализации UI.

## UI policy

Default: **custom UI components**.

Rules:
- Before creating a UI component, Cursor must check `.cursor/docs/component-inventory.md`.
- If a reusable custom component is created or significantly changed, Cursor must update `.cursor/docs/component-inventory.md` in the same task.
- Do not add a UI library (shadcn, MUI, Chakra и т.д.) without explicit confirmation.
- Portfolio-specific layout blocks (Hero, StatCard, ServiceCard) — в `components/` или `features/`, не дублировать базовые примитивы.

## Styling policy

- **Tailwind-first** — layout, spacing, typography, responsive, common UI.
- **CSS variables** — цвета, радиусы, тени, semantic tokens, theme layers.
- **SCSS Modules** — только для сложных scoped-блоков, где Tailwind становится нечитаемым (кастомные анимации, глубокая вложенность).
- **Global CSS** — reset, base styles, fonts, variables, theme (`app/globals.css`, позже `styles/tokens.css`, `styles/theme.css`).
- **Inline styles** — только для truly dynamic runtime values.

## Theme policy

Supported modes:
1. Light/dark theme (system preference + manual toggle — при реализации).
2. Brand theme с manually written tokens (акценты можно вывести из будущего фото).

Rules:
- Do not hardcode brand colors in components.
- Use semantic tokens: `bg-card`, `text-muted-foreground`, CSS variables, project-defined Tailwind tokens.
- New brand colors must be added to theme/tokens first.
- Референс задаёт настроение: светлая палитра, мягкие карточки, крупные скругления, воздушные отступы.

## Data fetching policy

**Frontend-only (текущий этап):**
- Контент — статический: TypeScript/JSON constants, MDX или hardcoded data в `lib/` / `features/*/data/`.
- Server Components — для статической разметки и metadata.
- Client Components — только где нужна интерактивность (theme toggle, mobile menu, анимации).
- API routes, Server Actions, Prisma, RTK Query — **не использовать** без явного запроса.

## Folder convention

Простая структура **без `src/`** (соответствует текущему `tsconfig` alias `@/*` → `./*`):

```text
app/           # App Router: pages, layouts, globals
components/    # reusable UI (Button, Card, Section…)
features/      # portfolio sections (hero, projects, contacts…)
shared/        # shared/ui, shared/lib, shared/config
lib/           # helpers, site config, content data
styles/        # tokens, theme layers (при выносе из globals.css)
public/        # static assets, references
```

Не вводить FSD, monorepo, repository pattern и т.п. без явной необходимости.

## Quality gate

Default checks after code changes:
- `npm run lint`
- `npm run build` for app-level changes
- `npm run typecheck` — **пока отсутствует**; добавить script при необходимости (`tsc --noEmit`)
- tests — когда появятся

## Hard no without explicit confirmation

- New UI library
- New state manager (Redux, Zustand, RTK Query)
- Prisma / database
- Express / custom API server
- Large folder restructuring (миграция в `src/` и т.д.)
- Auth/session model
- `git push`
- editing `.env` secrets directly

## Open questions

| # | Question | Default assumption |
|---|---|---|
| 1 | Точный список соцсетей и контактов | Placeholder-ссылки до предоставления данных |
| 2 | Язык интерфейса: только RU или RU+EN | RU на старте |
| 3 | Нужен ли blog / отдельные страницы кейсов | Одна landing-страница на первом этапе |
| 4 | Домен и хостинг | Vercel |
| 5 | Аналитика (Yandex Metrika, GA) | Не подключать без запроса |
| 6 | Шрифт: оставить Geist или сменить | Geist Sans до решения по дизайну |

## Recommendations (no auto-install)

- Добавить `typecheck` script: `"typecheck": "tsc --noEmit"`.
- При росте контента — вынести данные портфолио в `lib/content/` или `features/projects/data/`.
- Theme toggle — через `data-theme` на `<html>` и CSS variables (см. `.cursor/docs/theme-guide.md`).
- Оптимизировать изображения через `next/image`; фото профиля — в `public/images/`.
