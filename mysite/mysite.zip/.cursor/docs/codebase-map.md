# Codebase Map

Карта кодовой базы персонального портфолио Александра Блинова.

**Path alias:** `@/*` → `./*` (корень проекта, без `src/`).

## Current structure (MVP)

```text
mysite/
  app/
    layout.tsx              # root layout, ru, metadata, Geist fonts
    page.tsx                # portfolio landing (all sections)
    globals.css             # Tailwind + tokens/theme imports
    favicon.ico
  components/
    layout/
      container.tsx
      section.tsx
      header.tsx
      logo.tsx
      footer.tsx
      site-nav.tsx
      mobile-menu.tsx       # Client Component
    ui/
      button.tsx
      card.tsx
      badge.tsx
      icon-button.tsx
      modal.tsx
      theme-toggle.tsx
    theme/
      theme-init-script.tsx
  hooks/
    use-theme.ts
  features/
    hero/
      hero-section.tsx
      profile-image.tsx
    about/
      about-section.tsx
    stats/
      stats-section.tsx
    services/
      services-section.tsx
    skills/
      skills-section.tsx
    projects/
      projects-section.tsx
      project-card.tsx
    contacts/
      contacts-section.tsx
      social-links.tsx
  lib/
    theme.ts
    site-config.ts
    content/
      about.ts
      stats.ts
      services.ts
      skills.ts
      projects.ts
      contacts.ts
  styles/
    tokens.css
    theme.css
  public/
    images/
      profile-placeholder.svg
      project-placeholder.svg
    references/
      portfolio-reference.jpg
  .cursor/
  next.config.ts
  tsconfig.json
  postcss.config.mjs
  eslint.config.mjs
  package.json
```

## App / routing

| Path | Status | Notes |
|---|---|---|
| `app/layout.tsx` | exists | `lang="ru"`, OG metadata |
| `app/page.tsx` | exists | Single-page portfolio landing |
| `app/globals.css` | exists | Tailwind v4 + semantic tokens |
| `app/api/contact/route.ts` | exists | POST — SMTP contact form (nodemailer, Node.js runtime) |

## UI components

| Path | Status |
|---|---|
| `components/ui/**` | exists — Button, Card, Badge, IconButton |
| `components/layout/**` | exists — Container, Section, Header, Footer, SiteNav, MobileMenu |
| `shared/ui/**` | not used |

## Features

| Feature | Path | Section id |
|---|---|---|
| Hero | `features/hero/` | `#hero` |
| About | `features/about/` | `#about` |
| Stats | `features/stats/` | — |
| Services | `features/services/` | — |
| Skills | `features/skills/` | `#skills` |
| Projects | `features/projects/` | `#projects` |
| Contacts | `features/contacts/` | `#contacts` |

## API / data access

**Data source:** static content in `lib/content/*.ts`. Contact form → `POST /api/contact` (SMTP via nodemailer).

**Env (contact form, not in Git):** see `.env.example`. Required in Vercel: `SMTP_*`, `CONTACT_TO_EMAIL`, `CONTACT_FROM_EMAIL`. Gmail requires an app password (not account password). IMAP is not used.

## State

Only `MobileMenu` uses client state (`useState`). No global state manager.

## Styles / theme

| Path | Status |
|---|---|
| `app/globals.css` | exists — imports tokens + theme, `@theme inline` bridge |
| `styles/tokens.css` | exists — semantic HSL variables |
| `styles/theme.css` | exists — light/dark via `prefers-color-scheme` + `data-theme` |
| `*.module.scss` | not used |

## Static assets

| Path | Notes |
|---|---|
| `public/images/profile-placeholder.svg` | Hero photo placeholder |
| `public/images/project-placeholder.svg` | Project card placeholder |
| `public/references/portfolio-reference.jpg` | Design reference |
| `public/*.svg` (next, vercel…) | Legacy create-next-app assets; unused in page |

## Commands

| Command | Script | Status |
|---|---|---|
| Dev | `npm run dev` | available |
| Build | `npm run build` | available |
| Lint | `npm run lint` | available |
| Typecheck | `npx tsc --noEmit` | available (no npm script yet) |

## Import conventions

```ts
import { siteConfig } from '@/lib/site-config';
import { Button } from '@/components/ui/button';
import { HeroSection } from '@/features/hero/hero-section';
```
