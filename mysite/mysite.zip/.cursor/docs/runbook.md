# Project Runbook

Заполни команды под конкретный проект.

## Local development

```bash
npm install
npm run dev
```

## Quality checks

```bash
npm run lint
npm run typecheck
npm run build
```

If Prisma exists:

```bash
npx prisma validate
npx prisma generate
```

## Formatting

```bash
npm run format:check
npm run format
```

## Prisma

Development migration only after confirmation:

```bash
npx prisma migrate dev --name <name>
```

Production/staging deploy flow:

```bash
npx prisma migrate deploy
```

Forbidden without explicit confirmation:

```bash
npx prisma migrate reset
docker compose down -v
```

## Docker / VM

TODO:

```bash
docker compose ps
docker compose logs -f app
docker compose restart app
```

## Git workflow

User prefers commits through GitHub Desktop.
Cursor should not commit unless explicitly asked.
Before commit, run `/review-before-commit`.
