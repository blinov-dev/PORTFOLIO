# Tooling Standards

## ESLint

Purpose: code correctness and project rules.

Rules:
- Do not disable ESLint globally to pass checks.
- Do not add `eslint-disable` without a local reason.
- Do not change ESLint config without explicit confirmation unless the task is `/setup-eslint-prettier`.

## Prettier

Purpose: formatting only.

Rules:
- Prettier should not fight ESLint.
- Use `eslint-config-prettier` when ESLint and Prettier are both used.
- For Tailwind projects, prefer `prettier-plugin-tailwindcss`.

## Suggested scripts

Adjust to package manager and stack:

```json
{
  "scripts": {
    "lint": "eslint .",
    "lint:fix": "eslint . --fix",
    "typecheck": "tsc --noEmit",
    "format": "prettier . --write",
    "format:check": "prettier . --check",
    "build": "next build"
  }
}
```

For Vite/React replace build with project build command.
