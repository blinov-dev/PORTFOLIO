# API Contracts

Используется, если проект содержит Express API, Next route handlers или внешний API.

## Response format

TODO define one format, for example:

```ts
type ApiSuccess<T> = { ok: true; data: T };
type ApiError = { ok: false; error: { code: string; message: string; details?: unknown } };
```

## Validation

- Request validation: TODO, e.g. Zod.
- Response mapping: TODO.
- Auth boundary: TODO.

## Error handling

- Do not leak server stack traces to client.
- Use consistent HTTP status codes.
- Normalize unknown errors in one place.

## RTK Query

If RTK Query is used:
- Keep endpoints typed.
- Use tags/providesTags/invalidatesTags for cache invalidation.
- Do not manually refetch everywhere if tag invalidation can solve it.
