# Theme Guide

Руководство по стилизации и темам для портфолио Александра Блинова.

## Styling policy

- **Tailwind-first** — layout, spacing, typography, responsive, common UI.
- **CSS variables** — цвета, радиусы, тени, semantic tokens, theme switching.
- **SCSS Modules** — только для complex/custom scoped styling (анимации, глубокая вложенность).
- **Global CSS** — reset, base styles, fonts, variables (`app/globals.css`, позже `styles/`).

## Design reference

`public/references/portfolio-reference.jpg` — ориентир по настроению:
- светлая, чистая палитра с мягкими серыми фонами карточек;
- крупные скругления (bubble/soft feel);
- subtle shadows или тонкие borders;
- чёткая типографическая иерархия;
- card-based grid layout;
- профессионально, но дружелюбно.

**Не копировать 1:1** — адаптировать под frontend-портфолио и личный бренд.

## Theme modes

1. **Light** — default on first visit (`data-theme="light"` on `<html>`).
2. **Dark** — via `[data-theme='dark']` and manual toggle.

**Toggle:** `ThemeToggle` sets `document.documentElement.dataset.theme` and `localStorage` key `portfolio-theme`. Inline `ThemeInitScript` in `app/layout.tsx` restores saved theme before paint to reduce flash.

**Not in scope:** `system` / OS auto mode — only explicit `light` | `dark`.

`@media (prefers-color-scheme: dark)` in `styles/theme.css` applies only when `data-theme` is not `light`; with toggle, theme is always explicit after first interaction.

## Token architecture

### Layers

```text
app/globals.css          # Tailwind import, @theme inline bridge, smooth scroll
styles/tokens.css        # semantic CSS variables (HSL components)
styles/theme.css         # light/dark via prefers-color-scheme + data-theme
@theme inline { … }      # Tailwind v4 theme bridge (in globals.css)
```

**Status (MVP):** все три слоя реализованы. `globals.css` импортирует `styles/tokens.css` и `styles/theme.css`.

### Semantic tokens

| Token | Purpose |
|---|---|
| `--background` / `--foreground` | Warm white page / graphite text |
| `--card` / `--card-foreground` | Card surface |
| `--muted` / `--muted-foreground` | Secondary backgrounds and text |
| `--primary` | Violet — CTA, links, hover accents |
| `--secondary` | Raspberry/rose — gradient end, hover accents |
| `--accent` | Emerald/mint — status, Available badge only |
| `--border` | Soft borders |
| `--glass-bg`, `--glass-border`, `--glass-highlight`, `--glass-blur`, `--glass-shadow` | Liquid glass surfaces |
| `--gradient-primary`, `--gradient-primary-hover` | Violet → rose CTA gradient |
| `--gradient-ambient` | Page background glow |
| `--gradient-profile` | Hero profile card gradient |
| `--radius-*`, `--shadow-card` | Radius scale and elevation |

**Palette (light):** primary `265 62% 55%`, secondary `340 52% 56%`, accent `158 42% 45%`, background `35 28% 97%`. Blue accent removed.

### Glass utilities (`app/globals.css`)

| Class | Usage |
|---|---|
| `.glass-surface` | Cards, drawer, icon buttons |
| `.glass-header` | Sticky header |
| `.btn-gradient` | Primary CTA |
| `.btn-glass` | Secondary/outline CTA |
| `.card-hover` | Subtle lift on hover |
| `.gradient-text` | Role label in hero |
| `.drawer-panel` | Mobile menu slide-in |
| `.theme-toggle-*` | Liquid Glass pill switch (knob, track, icons) |

Long-form text blocks use `Card variant="solid"` for readability.

### Tailwind v4 bridge (current pattern)

В `app/globals.css` уже используется `@theme inline` для связи CSS vars с Tailwind utilities:

```css
@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --font-sans: var(--font-geist-sans);
  --font-mono: var(--font-geist-mono);
}
```

При расширении tokens — добавлять сюда semantic colors и radii, чтобы использовать `bg-card`, `text-muted-foreground`, `rounded-xl` и т.д.

## Typography

| Level | Tailwind (orientir) | Usage |
|---|---|---|
| Display | `text-4xl`–`text-5xl font-bold tracking-tight` | Имя в hero |
| H2 section | `text-2xl`–`text-3xl font-semibold` | Заголовки секций |
| H3 card | `text-lg font-medium` | Card titles |
| Body | `text-base leading-relaxed` | Описания, pitch |
| Label | `text-sm text-muted-foreground uppercase tracking-wide` | Роль, метки stat |
| Stat number | `text-3xl`–`text-4xl font-bold` | Крупные цифры |

Fonts: **Geist Sans** (body), **Geist Mono** (code/tech). Смена шрифта — через theme tokens и `next/font`.

## Spacing & layout

- Section vertical rhythm: `py-16`–`py-24` (responsive).
- Card padding: `p-6`–`p-8`.
- Grid gaps: `gap-4`–`gap-6`.
- Container: `max-w-6xl` or `max-w-7xl`, `px-4 sm:px-6 lg:px-8`.
- Hero: two-column on `lg+`, stacked on mobile.

## Component styling patterns

| Pattern | Approach |
|---|---|
| Cards | `bg-card rounded-xl shadow-card` or `rounded-2xl` for hero image |
| Buttons primary | `bg-primary text-primary-foreground rounded-full` |
| Buttons secondary | `border border-border rounded-full hover:bg-muted` |
| Social icons | Circular `IconButton`, muted bg, hover → primary |
| Nav links | `text-muted-foreground hover:text-foreground` |
| Profile image | Large `rounded-xl`/`rounded-2xl`, overflow hidden, `next/image` |

## SCSS Modules — when to use

Use `*.module.scss` only when:
- complex keyframe animations with many states;
- nested selectors become unreadable in Tailwind;
- pseudo-elements (`::before`, `::after`) with intricate styling;
- component-specific styling that doesn't belong in global theme.

Do **not** use SCSS for simple card/button layout — Tailwind is enough.

## Rules

- Do not hardcode brand colors in components (`#383838`, `bg-zinc-50` as one-offs).
- Use semantic classes/tokens: `bg-card`, `text-muted-foreground`, `border-border`.
- Add new semantic tokens before spreading one-off values across components.
- Do not fix dark mode locally in a single component — fix tokens in theme layer.
- Prefer responsive Tailwind utilities for layout.
- Replace create-next-app placeholder colors in `page.tsx` when implementing real UI.
- Brand accent may be derived from future profile photo — add to `[data-theme='brand']` first.

## Migration note

MVP реализован: HSL semantic tokens в `styles/tokens.css`, dark mode через `prefers-color-scheme` и `[data-theme='dark']` в `styles/theme.css`. Tailwind utilities: `bg-background`, `bg-card`, `text-muted-foreground`, `bg-primary`, `border-border` и т.д. через `@theme inline` в `app/globals.css`.

Manual theme toggle (ThemeProvider / ThemeToggle) — **реализован**: `components/ui/theme-toggle.tsx`, `hooks/use-theme.ts`, `lib/theme.ts`, `components/theme/theme-init-script.tsx`.
