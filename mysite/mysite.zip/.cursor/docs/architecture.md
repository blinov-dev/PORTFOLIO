# Architecture Notes

Источник истины — код проекта. Если этот документ расходится с кодом, Cursor должен сообщить об этом и не угадывать.

## Main architecture

TODO: опиши выбранный тип проекта.

Examples:
- Next fullstack: App Router + Server Components + Server Actions + Prisma.
- React SPA: Vite + RTK Query + Express API.
- Express API: routes/controllers/services/repositories + Prisma.

## Folder structure

Default simple structure:

```text
src/
  app/
  components/
  features/
  shared/
  lib/
  styles/
```

## Boundaries

- UI components must not access Prisma directly.
- Frontend must not import server-only code.
- Server-only secrets must stay server-side.
- API validation/error format must be consistent.
- Shared UI must be documented in component inventory.

## Important decisions

- TODO
