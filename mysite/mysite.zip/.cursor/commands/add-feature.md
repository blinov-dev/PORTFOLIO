# /add-feature

Добавь feature по существующей архитектуре проекта.

Перед кодом:
- прочитай project-profile, codebase-map, architecture;
- найди похожую feature;
- предложи минимальный scope.

Правила:
- новая feature должна следовать существующей структуре `src/features/**` или проектному паттерну;
- reusable UI — через component inventory;
- API/data/state — через выбранный project-profile;
- не добавлять новый state manager/API client/UI kit без подтверждения.

После:
- проверки;
- обновить docs, если добавлена новая архитектурная convention.
