# /implement-scope

Реализуй только явно указанный scope.

Перед началом:
- прочитай `.cursor/docs/project-profile.md`, `.cursor/docs/current-task.md`, `.cursor/docs/codebase-map.md`;
- если UI — прочитай `.cursor/docs/component-inventory.md` и `.cursor/docs/theme-guide.md`;
- выполни `git status --short`;
- остановись, если есть чужие незакоммиченные изменения, которые могут конфликтовать.

Правила:
- минимальный патч;
- не выходить за scope;
- не добавлять зависимости без подтверждения;
- миграции запускать только после отдельного подтверждения;
- не commit/push.

После:
- запусти релевантные проверки;
- если создан reusable UI component — обнови `.cursor/docs/component-inventory.md`;
- если изменены architecture/theme/API contracts — обнови соответствующий doc;
- короткий отчёт: файлы, проверки, status, diff stat, commit plan.
