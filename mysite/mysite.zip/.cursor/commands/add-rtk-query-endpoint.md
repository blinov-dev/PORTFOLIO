# /add-rtk-query-endpoint

Добавь endpoint в существующий RTK Query слой.

1. Найди существующий `baseApi` / API slice.
2. Не создавай новый API client без причины.
3. Типизируй request/response.
4. Добавь `providesTags`/`invalidatesTags`, если endpoint влияет на cache.
5. Не используй RTK Query для локального UI-state.
6. Обнови component/feature usage по существующему паттерну.
7. Запусти typecheck/lint.
