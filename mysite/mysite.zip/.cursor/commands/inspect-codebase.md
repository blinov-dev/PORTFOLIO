# /inspect-codebase

Цель: быстро понять существующую кодовую базу и обновить `.cursor/docs/codebase-map.md` + при необходимости `component-inventory.md`.

Не менять product code.

Шаги:
1. Посмотри package.json, tsconfig, config-файлы, структуру `src`, `server`, `prisma`.
2. Определи стек: Next/React/Vite/Express/Prisma/Tailwind/SCSS/RTK Query.
3. Найди основные UI-компоненты: Button/Input/Modal/Table/Layout/etc.
4. Найди data/API/state слой.
5. Обнови:
   - `.cursor/docs/codebase-map.md`;
   - `.cursor/docs/component-inventory.md`, если нашёл reusable UI;
   - `.cursor/docs/project-profile.md`, только если профиль пустой или явно устарел.
6. Отчёт: stack, структура, риски, что нужно уточнить.
