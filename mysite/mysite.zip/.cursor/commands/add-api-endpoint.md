# /add-api-endpoint

Добавь API endpoint по текущей архитектуре.

1. Определи backend mode: Next route handler / Express / external API wrapper.
2. Найди похожий endpoint.
3. Добавь validation по существующему паттерну.
4. Добавь auth/permission checks, если endpoint protected.
5. Сохрани единый response/error format.
6. Не добавляй Prisma в frontend/client code.
7. Обнови `.cursor/docs/api-contracts.md`, если меняется публичный контракт.
8. Запусти релевантные проверки.
