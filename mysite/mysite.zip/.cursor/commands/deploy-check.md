# /deploy-check

Проверка перед deploy.

1. Определи deploy mode: Docker/VM/Vercel/static/other.
2. Проверь env checklist, но не печатай секреты.
3. Проверь build commands.
4. Если Prisma есть — проверь migration flow.
5. Проверь persistent storage: DB, uploads, logs.
6. Проверь backup/rollback note.
7. Составь smoke-test checklist.
8. Не запускай production commands без подтверждения.
