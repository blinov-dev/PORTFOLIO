# /handoff

Сделай компактный handoff для продолжения работы в новом чате/Cursor.

Не менять код.

Включи:
- текущая цель;
- что сделано;
- что осталось;
- важные файлы;
- команды проверки;
- known issues;
- next safe step;
- commit status.

Если docs устарели — предложи обновить current-task/codebase-map.
