# /add-custom-ui-component

Создай reusable custom UI component.

1. Прочитай `.cursor/docs/component-inventory.md` и `.cursor/docs/theme-guide.md`.
2. Проверь, нет ли уже похожего компонента.
3. Если компонент уже есть — расширь его props или предложи refactor.
4. Новый компонент создавай в принятой UI-папке проекта.
5. Стили: Tailwind-first, CSS variables/theme tokens, SCSS Module только если нужно.
6. Добавь accessibility basics: semantic element, keyboard behavior, label/name when applicable.
7. Обнови `.cursor/docs/component-inventory.md` в той же задаче.
8. Добавь usage notes и props summary.
