# /setup-eslint-prettier

Настрой ESLint/Prettier аккуратно под текущий проект.

1. Определи стек: Next или React/Vite, TypeScript, Tailwind, package manager.
2. Проверь существующие configs/scripts.
3. Не ломай существующий стиль проекта.
4. Если configs уже есть — предложи минимальное улучшение, а не полную замену.
5. Для Tailwind предложи `prettier-plugin-tailwindcss`.
6. Для связки ESLint+Prettier предложи `eslint-config-prettier`, если есть конфликт форматирующих правил.
7. Обнови `.cursor/docs/tooling-standards.md`, если меняешь tooling.
8. Не устанавливай зависимости без подтверждения, если проект требует согласования.
9. После установки/правок проверь lint/format/typecheck.
