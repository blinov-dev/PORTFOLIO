# /create-project-profile

Создай или обнови `.cursor/docs/project-profile.md` по текущему проекту.

Не менять product code.

Проверь:
- package.json scripts/dependencies;
- app structure;
- backend/API наличие;
- Prisma наличие;
- state manager;
- styling/theme подход;
- UI library/custom UI;
- test/build/lint scripts;
- deploy hints.

Результат:
- заполненный project-profile;
- список вопросов, если что-то нельзя определить по коду;
- рекомендации, но без установки зависимостей.
