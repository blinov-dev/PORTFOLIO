# /update-docs

Обнови docs только по необходимости.

Правила:
- мелкий UI/CSS/label fix: docs обычно не трогать;
- новый reusable UI component: обновить `component-inventory.md`;
- изменён stack/profile: обновить `project-profile.md`;
- изменена структура: обновить `codebase-map.md`;
- изменены темы/tokens: обновить `theme-guide.md`;
- изменён API contract: обновить `api-contracts.md`;
- завершён крупный блок: обновить `current-task.md` и при необходимости `decisions.md`.

Не commit/push.
