# /a11y-check

Проверь accessibility для указанного UI.

Проверь:
- semantic HTML;
- keyboard navigation;
- labels/accessibile names;
- buttons vs clickable divs;
- focus states;
- modal/dialog behavior;
- form errors;
- table/list semantics;
- color contrast by tokens where possible.

Исправляй только в scope. Не делай большой UI refactor без подтверждения.
