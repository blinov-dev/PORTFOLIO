# /review-before-commit

Без коммита.

1. Выполни `git status --short` и `git diff --stat`.
2. Проверь, что нет `.env`, secrets, build artifacts, dumps, лишних архивов.
3. Проверь migrations: нужные `prisma/migrations/**/migration.sql` должны попасть в git.
4. Проверь, что `.cursor/` попадает в git только если задача была про Cursor Pack/setup.
5. Проверь commit message: без `Co-authored-by: Cursor` и `cursoragent@cursor.com`.
6. Предложи логические коммиты:
   - message;
   - список `git add <specific files>`;
   - кратко зачем.
7. Жди явного подтверждения пользователя.
