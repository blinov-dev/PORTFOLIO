# /add-prisma-model

Подготовь добавление Prisma model/schema change.

1. Объясни зачем нужна schema change.
2. Покажи proposed model/field changes.
3. Проверь связи, индексы, uniqueness, nullable/defaults.
4. Укажи migration name.
5. Остановись перед `prisma migrate dev` до подтверждения пользователя.
6. После подтверждения: migrate dev, prisma generate/validate, update data layer.
7. Не делай destructive changes без отдельного подтверждения.
