# /plan

Режим: только план. Не менять файлы и не запускать команды.

1. Прочитай `.cursor/docs/project-profile.md`, `.cursor/docs/current-task.md`, `.cursor/docs/codebase-map.md`.
2. Если задача про UI — прочитай `.cursor/docs/component-inventory.md` и `.cursor/docs/theme-guide.md`.
3. Найди только релевантные файлы, не сканируй весь проект.
4. Дай короткий план:
   - цель;
   - какие файлы создать/изменить;
   - что переиспользовать;
   - нужна ли миграция/новая зависимость;
   - что НЕ входит в scope;
   - риски;
   - проверки;
   - commit message suggestion.
5. Остановись и жди подтверждения.
