# /theme-audit

Проверь темы, стили и токены.

Не менять код без отдельного подтверждения, если аудит не просит сразу фиксить.

Проверь:
- raw hex/rgb/hsl цвета в компонентах;
- дубли brand colors;
- локальные фиксы dark mode вместо token/theme fix;
- inline styles;
- длинные нечитаемые Tailwind className;
- SCSS, который должен быть tokenized;
- отсутствие semantic tokens для card/text/border/background/primary.

Результат:
- список проблем по важности;
- быстрые фиксы;
- системные фиксы;
- какие файлы менять.
