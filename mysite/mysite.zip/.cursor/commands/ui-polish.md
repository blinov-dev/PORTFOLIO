# /ui-polish

Полировка UI без изменения бизнес-логики.

1. Прочитай component-inventory и theme-guide.
2. Используй Tailwind-first + tokens.
3. Не хардкодь цвета/темы.
4. Не создавай новый reusable component, если можно использовать существующий.
5. Проверь responsive/mobile.
6. Проверь basic accessibility.
7. Не меняй data/API/business behavior.
