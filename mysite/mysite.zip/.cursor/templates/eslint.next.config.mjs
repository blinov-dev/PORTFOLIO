/**
 * Example ESLint flat config for Next.js projects.
 * Adjust to the project's Next/ESLint version before using.
 */
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { FlatCompat } from '@eslint/eslintrc';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const compat = new FlatCompat({ baseDirectory: __dirname });

const eslintConfig = [
  ...compat.extends('next/core-web-vitals', 'next/typescript'),
  ...compat.extends('prettier'),
  {
    ignores: ['.next/**', 'node_modules/**', 'dist/**', 'build/**'],
  },
];

export default eslintConfig;
