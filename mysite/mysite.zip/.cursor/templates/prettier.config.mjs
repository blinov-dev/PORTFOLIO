/**
 * Generic Prettier config for Tailwind-first projects.
 * Copy to project root only if project uses Prettier.
 */
const config = {
  singleQuote: true,
  semi: true,
  trailingComma: 'all',
  printWidth: 100,
  plugins: ['prettier-plugin-tailwindcss'],
};

export default config;
