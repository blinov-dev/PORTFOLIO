# Cursor Golden Pack v1 — Frontend/Fullstack

Пакет для проектов на Next.js / React / TypeScript / Prisma / Express / Tailwind / SCSS / RTK Query.

## Как использовать

1. Скопируй папку `.cursor` в корень проекта.
2. Открой `.cursor/docs/project-profile.md` и заполни профиль проекта.
3. Запусти в Cursor команду `/inspect-codebase`, чтобы он составил карту проекта.
4. Запусти `/create-project-profile`, если проект уже существует и профиль нужно собрать по коду.
5. Перед крупной задачей используй `/plan`.
6. Для мелких правок используй `/microfix`.
7. Перед коммитом через GitHub Desktop используй `/review-before-commit`.

## Главная идея

Пакет не должен делать все проекты одинаковыми. Cursor обязан сначала понять профиль проекта:

- Next fullstack или React SPA;
- есть ли Express API;
- есть ли Prisma;
- Tailwind/SCSS политика;
- custom UI или UI-библиотека;
- используется ли RTK Query;
- какая тема: light/dark или brand tokens.

## Базовая структура проекта по умолчанию

```text
src/
  app/          # Next App Router или app bootstrap
  components/   # общие/переиспользуемые компоненты проекта
  features/     # бизнес-фичи
  shared/       # shared/ui, shared/lib, shared/api, shared/config
  lib/          # project-level helpers/adapters
  styles/       # globals, variables, theme, mixins
```

Эту структуру можно менять под проект, но Cursor не должен придумывать новую без причины.

## Источники и ориентиры

- Cursor Project Rules: https://cursor.com/docs/rules
- Next.js Server/Client Components: https://nextjs.org/docs/app/getting-started/server-and-client-components
- Next.js ESLint: https://nextjs.org/docs/app/api-reference/config/eslint
- Tailwind CSS theme variables: https://tailwindcss.com/docs/theme
- Tailwind Prettier plugin: https://tailwindcss.com/docs/editor-setup
- RTK Query automated refetching: https://redux-toolkit.js.org/rtk-query/usage/automated-refetching
- Prisma migrate deploy: https://www.prisma.io/docs/orm/prisma-client/deployment/deploy-database-changes-with-prisma-migrate
